package com.vcore.core.system.user;

public enum BUserStatus {
    ENABLE, DISABLE

}
