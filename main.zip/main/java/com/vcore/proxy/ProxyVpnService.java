package com.vcore.proxy;

import android.net.VpnService;

public class ProxyVpnService extends VpnService { }
