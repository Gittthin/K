#include "BaseHook.h"

void BaseHook::init(JNIEnv *env) {

}
