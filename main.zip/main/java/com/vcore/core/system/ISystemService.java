package com.vcore.core.system;

public interface ISystemService {
    void systemReady();
}
